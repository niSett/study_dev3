<?php
    //using general namespace
    //namespace app\core;

    //use this namespace
    use app\controllers\AuthController;
    use app\controllers\SiteController;
    use app\core\Application;

    //request autoload file
    require_once __DIR__ . '/vendor/autoload.php';

    $dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
    $dotenv->load(); 

    $config = [
        'db' => [
            'dsn' => $_ENV['DB_DSN'],
            'user' => $_ENV['DB_USER'],
            'password' => $_ENV['DB_PASSWORD'],
        ]
    ];

    //new object app
    $app = new Application(__DIR__, $config);

    //run our app
    $app->db->applyMigrations();
?>